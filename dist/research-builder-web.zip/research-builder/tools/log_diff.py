#!/usr/bin/env python3
"""Compare the warnings of two LaTeX builds of the same paper.

A late wording change can add an overfull line, an undefined reference or a
font substitution that a look at the PDF does not reveal. Compile the previous
version under a temporary name in the same directory, so that relative paths
resolve in the same way, and compare its log with the log of the new build.

    python tools/log_diff.py old.log new.log
    python tools/log_diff.py old.log new.log --job paper_v1 --job paper_v2

Warnings are compared as multisets. Before the comparison the job names (the
file names of the two logs, plus any --job), input line numbers and page numbers
are replaced by placeholders, so that a source line that moved does not count
as a change. Box sizes are kept, a changed size is a changed warning. Exit status
is 0 when the new log has no warning that the old log lacks, 1 otherwise.
"""
import argparse
import collections
import os
import re
import sys

START = re.compile(r'Warning|Overfull|Underfull|Missing character|undefined|^! ')
# continuation lines of a package warning start with the package name in parentheses
CONT = re.compile(r'^\([A-Za-z@][\w@.-]*\)\s')
WRAP = 79  # TeX breaks log lines at max_print_line


def entries(path):
    lines = open(path, encoding='latin-1').read().splitlines()
    out, i = [], 0
    while i < len(lines):
        if START.search(lines[i]):
            buf, j = [lines[i]], i + 1
            while j < len(lines) and (len(lines[j - 1]) >= WRAP or CONT.match(lines[j])):
                buf.append(lines[j])
                j += 1
            out.append(' '.join(x.strip() for x in buf))
            i = j
        else:
            i += 1
    return out


def normalize(entry, jobs):
    for job in sorted(jobs, key=len, reverse=True):
        entry = entry.replace(job, 'JOB')
    entry = re.sub(r'on input line \d+', 'on input line N', entry)
    entry = re.sub(r'at lines? \d+(--\d+)?', 'at lines N', entry)
    entry = re.sub(r'on page \d+', 'on page N', entry)
    entry = re.sub(r'\[\d+\]', '[N]', entry)
    return ' '.join(entry.split())


def main():
    ap = argparse.ArgumentParser(description=__doc__.split('\n\n')[0])
    ap.add_argument('old')
    ap.add_argument('new')
    ap.add_argument('--job', action='append', default=[], help='another job name to replace, repeatable')
    a = ap.parse_args()
    jobs = set(a.job) | {os.path.splitext(os.path.basename(p))[0] for p in (a.old, a.new)}
    old = collections.Counter(normalize(e, jobs) for e in entries(a.old))
    new = collections.Counter(normalize(e, jobs) for e in entries(a.new))
    added, removed = new - old, old - new
    print(f'warnings: {sum(old.values())} in {a.old}, {sum(new.values())} in {a.new}')
    print(f'only in the new build ({sum(added.values())}):')
    for e, n in sorted(added.items()):
        print(f'  {n}x {e}')
    print(f'only in the old build ({sum(removed.values())}):')
    for e, n in sorted(removed.items()):
        print(f'  {n}x {e}')
    sys.exit(1 if added else 0)


if __name__ == '__main__':
    main()
